
#ifndef STACK_INCLUDED 
#define STACK_INCLUDED  1

#include <iostream>
#include <initializer_list>

class stack 
{
	size_t current_size;
	size_t current_capacity; 

	double* data; 
	// INVARIANТ: has been allocated with size current_capacity.
	// 0 <= current_size <= current_capacity. 

	void ensure_capacity( size_t c );
	// Ensure that stack has capacity of at least c.
	// This function is given, so you don't have to write it. 

	public: 

	stack(){
		current_capacity = 0;
		current_size = 0;
		data = new double[0];
	}


	stack(const stack &s):
		current_size {s.current_size},
	current_capacity {s.current_capacity},
	data {new double[current_capacity]}
	{
		size_t counter = 0;
		while(counter != s.current_size)
		{
			data[counter] = s.data[counter];
			counter++;
		}
	}

	stack(const std::initializer_list <double> init){
		ensure_capacity(init.size());
		for(double counter : init)
		{
			data[current_size] = counter;
			current_size ++;
		}
	}


	~stack()
	{
		delete[] data;
	}


	const stack& operator = (const stack &s)
	{
		ensure_capacity(s.current_capacity);
		size_t counter = 0;
		while( counter != s.current_size )
		{
			data[counter] = s.data[counter];
			counter++;
		}
		return *this;
	}

	void push(double d)
	{
		ensure_capacity(current_size + 1);
		data[current_size] = d;
		current_size++;
	}


	void pop(){
		current_size --;
	}



	void clear(){
		current_size = 0;
	}

	void reset( size_t s ){
		current_size = s;
	}

	double peek() const {
		return data[current_size - 1];
	}


	size_t size() const {
		return current_size;
	}

	bool empty() const {
		return (size() == 0);
	}


	friend std::ostream& operator << ( std::ostream& , const stack& ); 
}; 

#endif

